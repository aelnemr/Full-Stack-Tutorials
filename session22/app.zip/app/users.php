<?php
require_once 'config/config.php';

_header('USERS');
?>


    Content

<?php
_footer();